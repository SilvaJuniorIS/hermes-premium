from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from src.hermes_db import init_db, load_recent_api_runs, load_recent_licitacoes
from src.main import DEFAULT_CONFIG, run_pipeline


app = FastAPI(title="Hermes Premium")


class RunRequest(BaseModel):
    perfil: str = "limpeza_higiene"
    config: dict[str, Any] | None = None


@app.on_event("startup")
def startup() -> None:
    init_db()


@app.get("/", response_class=HTMLResponse)
def dashboard() -> str:
    dashboard_path = Path("dashboard.html")
    return dashboard_path.read_text(encoding="utf-8")


@app.post("/run")
def run(req: RunRequest) -> dict[str, Any]:
    config = {**DEFAULT_CONFIG, **(req.config or {})}
    result = run_pipeline(req.perfil, config)
    return {
        "status": result["status"],
        "run_id": result["run_id"],
        "stats": result["stats"],
    }


@app.get("/licitacoes")
def listar(limit: int = 100) -> list[dict[str, Any]]:
    return load_recent_licitacoes(limit=limit)


@app.get("/runs")
def runs() -> list[dict[str, Any]]:
    return load_recent_api_runs()


@app.get("/health")
def health() -> dict[str, str]:
    init_db()
    return {"status": "ok"}
