import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from src.config import DB_PATH


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def parse_money(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip()
    if not text:
        return 0.0

    try:
        text = (
            text.replace("R$", "")
            .replace(" ", "")
            .replace(".", "")
            .replace(",", ".")
        )
        return float(text)
    except (TypeError, ValueError):
        return 0.0


@contextmanager
def connect(db_path: Path | str = DB_PATH):
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}


def _add_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    if column not in _columns(conn, table):
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def ensure_schema(db_path: Path | str = DB_PATH) -> None:
    with connect(db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS api_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                start_time TEXT NOT NULL,
                end_time TEXT,
                status TEXT NOT NULL,
                stats TEXT,
                perfil TEXT,
                notes TEXT
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS api_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                run_id INTEGER,
                event_type TEXT,
                message TEXT NOT NULL,
                meta TEXT
            )
        """)
        _add_column(conn, "api_events", "run_id", "INTEGER")
        _add_column(conn, "api_events", "event_type", "TEXT")
        _add_column(conn, "api_events", "meta", "TEXT")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS licitacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pncp_id TEXT,
                objeto TEXT,
                valor_estimado_num REAL DEFAULT 0,
                estado TEXT,
                municipio TEXT,
                orgao TEXT,
                keyword TEXT,
                data_abertura TEXT,
                score REAL DEFAULT 0,
                classificacao TEXT,
                oportunidade TEXT,
                delta_preco REAL DEFAULT 0,
                link TEXT,
                source TEXT,
                raw_json TEXT,
                first_seen_at TEXT,
                last_seen_at TEXT
            )
        """)

        for column, ddl in {
            "id": "INTEGER",
            "pncp_id": "TEXT",
            "objeto": "TEXT",
            "valor_estimado_num": "REAL DEFAULT 0",
            "estado": "TEXT",
            "municipio": "TEXT",
            "orgao": "TEXT",
            "keyword": "TEXT",
            "data_abertura": "TEXT",
            "score": "REAL DEFAULT 0",
            "classificacao": "TEXT",
            "oportunidade": "TEXT",
            "delta_preco": "REAL DEFAULT 0",
            "link": "TEXT",
            "source": "TEXT",
            "raw_json": "TEXT",
            "first_seen_at": "TEXT",
            "last_seen_at": "TEXT",
        }.items():
            if column != "id":
                _add_column(conn, "licitacoes", column, ddl)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pncp_id TEXT,
                keyword TEXT,
                estado TEXT,
                valor_estimado_num REAL,
                collected_at TEXT NOT NULL
            )
        """)

        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_licitacoes_pncp_id "
            "ON licitacoes(pncp_id)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_licitacoes_last_seen "
            "ON licitacoes(last_seen_at)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_licitacoes_score "
            "ON licitacoes(score)"
        )
        conn.execute(
            """
            DELETE FROM licitacoes
            WHERE pncp_id IS NULL
               OR TRIM(COALESCE(pncp_id, '')) = ''
               OR LOWER(TRIM(COALESCE(pncp_id, ''))) = 'none'
               OR objeto IS NULL
               OR TRIM(COALESCE(objeto, '')) = ''
               OR LOWER(TRIM(COALESCE(objeto, ''))) = 'none'
            """
        )


def init_db(db_path: Path | str = DB_PATH) -> None:
    ensure_schema(db_path)


def start_run(perfil: str | None = None, db_path: Path | str = DB_PATH) -> int:
    ensure_schema(db_path)
    with connect(db_path) as conn:
        cur = conn.execute(
            """
            INSERT INTO api_runs(start_time, status, perfil)
            VALUES (?, ?, ?)
            """,
            (now_iso(), "running", perfil),
        )
        return int(cur.lastrowid)


def finish_run(
    run_id: int,
    stats: dict[str, Any],
    status: str = "finished",
    notes: str = "",
    db_path: Path | str = DB_PATH,
) -> None:
    with connect(db_path) as conn:
        conn.execute(
            """
            UPDATE api_runs
            SET end_time = ?,
                status = ?,
                stats = ?,
                notes = ?
            WHERE id = ?
            """,
            (now_iso(), status, json.dumps(stats, ensure_ascii=False), notes, run_id),
        )


def log_event(
    run_id: int | None,
    event_type: str,
    message: str,
    db_path: Path | str = DB_PATH,
    **kwargs: Any,
) -> None:
    ensure_schema(db_path)
    with connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO api_events (created_at, run_id, event_type, message, meta)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                now_iso(),
                run_id,
                event_type,
                message,
                json.dumps(kwargs, ensure_ascii=False) if kwargs else None,
            ),
        )


def upsert_licitacoes(
    licitacoes: list[dict[str, Any]],
    db_path: Path | str = DB_PATH,
) -> int:
    ensure_schema(db_path)
    saved = 0
    seen_at = now_iso()

    with connect(db_path) as conn:
        for lic in licitacoes:
            pncp_id = str(lic.get("pncp_id") or "").strip()
            if not pncp_id:
                continue

            valor = parse_money(lic.get("valor_estimado_num"))
            raw = lic.get("raw")

            conn.execute(
                """
                INSERT INTO licitacoes (
                    pncp_id, objeto, valor_estimado_num, estado, municipio,
                    orgao, keyword, data_abertura, score, classificacao,
                    oportunidade, delta_preco, link, source, raw_json,
                    first_seen_at, last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(pncp_id) DO UPDATE SET
                    objeto = excluded.objeto,
                    valor_estimado_num = excluded.valor_estimado_num,
                    estado = excluded.estado,
                    municipio = excluded.municipio,
                    orgao = excluded.orgao,
                    keyword = excluded.keyword,
                    data_abertura = excluded.data_abertura,
                    score = excluded.score,
                    classificacao = excluded.classificacao,
                    oportunidade = excluded.oportunidade,
                    delta_preco = excluded.delta_preco,
                    link = excluded.link,
                    source = excluded.source,
                    raw_json = excluded.raw_json,
                    last_seen_at = excluded.last_seen_at
                """,
                (
                    pncp_id,
                    lic.get("objeto"),
                    valor,
                    lic.get("estado"),
                    lic.get("municipio"),
                    lic.get("orgao"),
                    lic.get("keyword"),
                    lic.get("data_abertura"),
                    lic.get("score", 0),
                    lic.get("classificacao"),
                    lic.get("oportunidade"),
                    lic.get("delta_preco", 0),
                    lic.get("link"),
                    lic.get("source", "pncp"),
                    json.dumps(raw, ensure_ascii=False) if raw is not None else None,
                    seen_at,
                    seen_at,
                ),
            )

            if valor > 0:
                conn.execute(
                    """
                    INSERT INTO price_history (
                        pncp_id, keyword, estado, valor_estimado_num, collected_at
                    ) VALUES (?, ?, ?, ?, ?)
                    """,
                    (pncp_id, lic.get("keyword"), lic.get("estado"), valor, seen_at),
                )

            saved += 1

    return saved


def load_recent_licitacoes(
    limit: int = 100,
    db_path: Path | str = DB_PATH,
) -> list[dict[str, Any]]:
    ensure_schema(db_path)
    with connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT
                pncp_id, objeto, valor_estimado_num, estado, municipio, orgao,
                keyword, data_abertura, score, classificacao, oportunidade,
                delta_preco, link, source, first_seen_at, last_seen_at
            FROM licitacoes
            ORDER BY score DESC, valor_estimado_num DESC, last_seen_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    return [dict(row) for row in rows]


def load_recent_api_runs(db_path: Path | str = DB_PATH) -> list[dict[str, Any]]:
    ensure_schema(db_path)
    with connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT *
            FROM api_runs
            ORDER BY id DESC
            LIMIT 50
            """
        ).fetchall()

    return [dict(row) for row in rows]


def get_price_reference(
    keyword: str | None,
    estado: str | None,
    db_path: Path | str = DB_PATH,
) -> dict[str, Any]:
    if not keyword or not estado:
        return {"media": None}

    ensure_schema(db_path)
    with connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT valor_estimado_num
            FROM price_history
            WHERE keyword = ?
              AND estado = ?
              AND valor_estimado_num > 0
            ORDER BY collected_at DESC
            LIMIT 200
            """,
            (keyword, estado),
        ).fetchall()

    values = [float(row["valor_estimado_num"]) for row in rows]
    if not values:
        return {"media": None}

    return {
        "media": sum(values) / len(values),
        "min": min(values),
        "max": max(values),
        "amostras": len(values),
    }
